import { Pipe, PipeTransform } from '@angular/core';


interface Product {
 productName: string;
 price : number;
 productDescription : string;
 imageUrl : string
}


@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(products : Product[], search: string): Product[] {
   if(search === undefined){
     return products;
   }else{
    return products.filter(product =>{
      if(product.productName.toLowerCase().includes(search.toLowerCase())){
        return true;
      }else{
        return false;
      }
    });
   }
  }

}
